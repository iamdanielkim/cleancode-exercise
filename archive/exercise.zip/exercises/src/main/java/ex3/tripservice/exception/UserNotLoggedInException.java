package ex3.tripservice.exception;

public class UserNotLoggedInException extends RuntimeException {

	private static final long serialVersionUID = 8959479918185637340L;

}
