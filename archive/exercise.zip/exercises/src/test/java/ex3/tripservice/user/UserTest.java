package ex3.tripservice.user;

public class UserTest {

}
